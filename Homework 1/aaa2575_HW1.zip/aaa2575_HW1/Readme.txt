This program would perform basic mathematical functions on integers and doubles
To always ensure positive numbers as output please make sure the first number entered is larger than the second number entered 


To compile aaa2575_Hello_World_1.cpp you will need the following commands 
g++ -o output1 aaa2575_Hello_World_1.cpp
./output1


Sample input could be:
Hello and welcome!

Please enter your first and last name: Atafo Abure
Thanks Atafo Abure for telling me your name.

Please eneter two integers: 25 10

The sum of these two numbers is 35
The difference of these two numbers is 15
The product of these two numbers is 250
The quotient of these two numbers is 2

Please enter two doubles 17.3 12.5

The sum of these two numbers is 29.8
The difference of these two numbers is 4.8
The product of these two numbers is 216.25
The quotient of these two numbers is 1.384

Thanks you for time Atafo Abure


To compile aaa2575_Hello_World_2.cpp you will need the following commands 
g++ -o output2 aaa2575_Hello_World_2.cpp
./output2

Sample input could be:
Hello and welcome!

Please enter your first and last name: Atafo Abure
Thanks <username> for telling me your name.

Please enter two integers: 25 10

The sum of these two numbers is 35
The difference of these two numbers is 15
The product of these two numbers is 250
The quotient of these two numbers is 2

Please enter two doubles 17.3 12.5

The sum of these two numbers is 29.8
The difference of these two numbers is 4.8
The product of these two numbers is 216.25
The quotient of these two numbers is 1.384

Thanks you for time <username>

To create a new user account for aaa2575_Hello_World_2.cpp you will need the following commands
sudo adduser username 
Username should be replaced with the username of the new account you wish to add

